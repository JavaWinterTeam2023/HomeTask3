package Test;

import java.util.concurrent.Semaphore;

import Model.ChargingStation;
import Services.ChargingVehicleService;

public class TestEnvironment {
    public static void main(String[] args) {
        //final int availableChargingPoints = 5;
        //final int totalVehicles = 15;

        //ChargingStation chargingStation = new ChargingStation(availableChargingPoints);

       // for (int i = 1; i <= totalVehicles; i++) {
        	//ChargingVehicleService service = new ChargingVehicleService(chargingStation, i);
          //  new Thread(service).start();

           // try {
                // Brief pause to stagger vehicle arrival times
              //  Thread.sleep(500);
            //} catch (InterruptedException e) {
               // Thread.currentThread().interrupt();
           // }
        //}
    }
}